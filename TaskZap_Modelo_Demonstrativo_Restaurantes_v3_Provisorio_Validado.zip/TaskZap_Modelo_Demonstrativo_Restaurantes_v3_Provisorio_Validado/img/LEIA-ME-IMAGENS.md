# Imagens — Sabor da Casa / TaskZap

> ⚠️ **STATUS: PROVISÓRIO.** As imagens desta pasta são composições
> abstratas usadas apenas para o site funcionar sem links quebrados
> durante o desenvolvimento e os testes. Elas **não devem** ser usadas
> na apresentação comercial final. A especificação oficial de
> substituição (nome exato, dimensão, proporção e orientação visual de
> cada arquivo) está em **`../PENDENTE-IMAGENS-REALISTAS.md`** — use
> esse documento como referência para a fotografia real.

Todas as imagens abaixo são **composições estilizadas e fictícias**,
criadas especialmente para este modelo (mesa/prato com iluminação quente,
nos tons verde/creme/laranja/mostarda do site). **Não são fotografias
reais** — servem como placeholder de alta qualidade, visualmente
coerente entre si, pronto para ir ao ar num modelo demonstrativo ou ser
substituído pelas fotos reais do cliente. Nenhuma imagem contém texto,
marca de terceiros ou pertence a um estabelecimento existente.

**Para o cliente final: substitua cada arquivo pela foto profissional
real, mantendo exatamente o mesmo nome de arquivo** — assim o `CONFIG`
dentro do `index.html` não precisa ser alterado.

---

### `hero.webp`
- **Onde aparece:** banner principal (topo do site).
- **Dimensão do arquivo:** 1600×2000px.
- **Proporção:** 4:5 (vertical). No celular, o CSS recorta a mesma
  imagem em 5:4 (horizontal) automaticamente — não é preciso gerar dois
  arquivos, mas ao fotografar deixe **espaço de respiro nas bordas**
  (assunto centralizado) para o recorte funcionar bem nos dois formatos.
- **Formato:** WebP.
- **Como substituir:** troque o arquivo mantendo o nome `hero.webp`, ou
  aponte `CONFIG.imagens.hero` para outro caminho.
- **Cuidados com corte:** evite elementos importantes muito perto das
  bordas superior/inferior — no celular a imagem fica mais "quadrada" e
  corta os extremos verticais.
- **Peso recomendado:** até 150 KB (arquivo atual: ~26 KB).

### `sobre.webp`
- **Onde aparece:** seção "Sobre" (preparo/ambiente).
- **Dimensão:** 1400×1400px.
- **Proporção:** 1:1 (quadrada).
- **Formato:** WebP.
- **Como substituir:** mesmo nome de arquivo, ou `CONFIG.imagens.sobre`.
- **Cuidados com corte:** por ser quadrada, evite fotos muito panorâmicas
  — prefira enquadramento já próximo do quadrado na captura original.
- **Peso recomendado:** até 120 KB (arquivo atual: ~18 KB).

### Fotos de produtos do cardápio
`marmita-tradicional.webp` · `marmita-fitness.webp` ·
`marmita-vegetariana.webp` · `feijoada.webp` · `frango-quiabo.webp` ·
`parmegiana.webp` · `porcoes.webp` · `bebidas.webp` · `sobremesas.webp`

- **Onde aparecem:** card de cada item do cardápio (campo `foto` de cada
  produto em `CONFIG.categorias`).
- **Dimensão:** 1200×800px.
- **Proporção:** 16:11 (levemente mais larga que alta).
- **Formato:** WebP.
- **Como substituir:** troque o arquivo (mesmo nome) ou aponte o campo
  `foto` do item correspondente em `CONFIG.categorias` para outro caminho.
  As categorias com 3 produtos (Porções, Bebidas, Sobremesas) reaproveitam
  uma imagem genérica por categoria — para foto individual por produto,
  adicione o novo arquivo e aponte o `foto` daquele item específico.
- **Cuidados com corte:** o card tem `object-fit:cover`, então o centro
  da imagem é sempre priorizado — centralize o prato/produto.
- **Peso recomendado:** até 80 KB cada (arquivos atuais: ~11–12 KB).

### `compartilhamento.webp`
- **Onde aparece:** prévia do link ao compartilhar o site no
  WhatsApp/redes sociais (Open Graph / Twitter Card).
- **Dimensão:** 1200×630px (obrigatória — é o padrão universal de OG image).
- **Proporção:** 1.91:1.
- **Formato:** WebP.
- **Conteúdo:** logo "Sabor da Casa", nome da marca, a frase "Comida
  caseira feita com carinho" e o selo discreto "Modelo demonstrativo ·
  TaskZap" — sem telefone, endereço ou qualquer dado real.
- **Como substituir:** troque o arquivo (mesmo nome) ou aponte
  `CONFIG.imagens.compartilhamento`. Ao trocar, mantenha a proporção
  1200×630 exata — plataformas cortam de forma imprevisível se o
  tamanho for diferente.
- **Peso recomendado:** até 300 KB (arquivo atual: ~20 KB).

### `logo.png`
- **Onde aparece:** badge do cabeçalho e do rodapé; também usado como
  favicon (ícone da aba do navegador).
- **Dimensão:** 512×512px.
- **Proporção:** 1:1, fundo **transparente**.
- **Formato:** PNG (com canal alfa).
- **Como substituir:** troque o arquivo mantendo `logo.png`, ou aponte
  `CONFIG.imagens.logo`. Se o arquivo não carregar, o site mostra
  automaticamente o emoji definido em `CONFIG.identidade.emoji` no lugar
  — sem ícone de imagem quebrada (fallback já implementado no motor).
- **Cuidados com corte:** o badge do cabeçalho é pequeno (~38×38px) —
  use um símbolo simples, sem detalhes finos que somem em tamanho reduzido.
- **Peso recomendado:** até 30 KB (arquivo atual: ~2 KB).

---

## Resumo de pesos (arquivo atual do modelo)

| Arquivo | Peso |
|---|---|
| hero.webp | ~26 KB |
| sobre.webp | ~18 KB |
| marmita-tradicional.webp | ~12 KB |
| marmita-fitness.webp | ~11 KB |
| marmita-vegetariana.webp | ~11 KB |
| feijoada.webp | ~11 KB |
| frango-quiabo.webp | ~11 KB |
| parmegiana.webp | ~12 KB |
| porcoes.webp | ~12 KB |
| bebidas.webp | ~12 KB |
| sobremesas.webp | ~11 KB |
| compartilhamento.webp | ~20 KB |
| logo.png | ~2 KB |
| **Total** | **~169 KB** |

## Especificação para fotos reais do cliente (na hora de substituir)
- Iluminação natural, aparência profissional, mesmo padrão visual entre elas.
- Sem logotipos de terceiros e sem texto sobre a imagem (exceto na
  imagem de compartilhamento, que pode ter nome/logo/tagline).
- Não usar fotos de estabelecimentos reais sem autorização do cliente.
- Exportar em WebP; alvo geral abaixo de 150 KB por imagem.
- Respeitar as proporções desta tabela para não cortar o layout.
