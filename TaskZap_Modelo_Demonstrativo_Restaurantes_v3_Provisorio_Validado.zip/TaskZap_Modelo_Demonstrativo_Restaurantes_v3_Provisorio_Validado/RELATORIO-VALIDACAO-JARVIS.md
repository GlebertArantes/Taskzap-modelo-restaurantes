# Relatório de Validação — Jarvis

**Projeto:** TaskZap — Modelo Demonstrativo de Restaurantes v3  
**Status:** código validado; imagens comerciais pendentes  
**Data:** 24/07/2026

## Resultado geral

O pacote técnico foi extraído, executado e validado. O `index.html` desta pasta é idêntico ao HTML previamente aprovado.

- SHA-256 do `index.html`: `e6362b67a925f96632082d8d2db8b43920799fd3b443b0acf07e52e79fa48c84`
- Modo entregue: `modoDemonstracao: true`
- Imagens quebradas: nenhuma
- Erros de JavaScript durante a execução: nenhum
- Falhas de carregamento dos arquivos locais: nenhuma

## Larguras testadas

Foram testadas as larguras: **320, 375, 390, 430, 768, 1024 e 1440 px**.

Em todas elas:

- a largura do conteúdo permaneceu dentro da viewport;
- não houve rolagem horizontal;
- o modal abriu e fechou;
- a página permaneceu utilizável.

## Funcionalidades verificadas

- Menu mobile fechado totalmente invisível;
- Menu mobile abre e atualiza `aria-expanded`;
- Categorias do cardápio alternam corretamente;
- Modal abre a partir de um item;
- Quantidade altera o total;
- Entrega/retirada altera a prévia;
- Exemplo validado: Feijoada da Casa, 2 unidades, retirada = R$ 68,00;
- Modo demonstração não abre o WhatsApp real;
- Teste temporário em modo real gerou corretamente uma URL `wa.me`, sem envio automático;
- Todos os arquivos da pasta `img/` foram carregados;
- Capturas reais foram gravadas na pasta `prints/`.

## Pendências antes da publicação comercial

- Substituir as imagens abstratas por fotografias profissionais ou imagens licenciadas;
- Escolher a URL final no Netlify;
- Preencher `canonical`, `og:url`, `og:image` e `twitter:image` com URLs absolutas;
- Gerar novamente os prints depois da substituição das imagens;
- Testar a prévia do link após a publicação.

## Aprovação

Este pacote está **aprovado para armazenamento no GitHub e como base oficial de desenvolvimento**. Ainda não está aprovado como demonstração comercial definitiva por causa das imagens provisórias.
