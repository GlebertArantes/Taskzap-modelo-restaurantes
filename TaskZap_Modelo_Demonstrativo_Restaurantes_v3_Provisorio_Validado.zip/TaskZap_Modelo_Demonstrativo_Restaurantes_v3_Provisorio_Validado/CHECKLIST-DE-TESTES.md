# Checklist de Testes — Sabor da Casa / TaskZap

> 🟡 **Status desta versão: PROVISÓRIA PARA IMAGENS.** O código e a estrutura foram validados em navegador real, mas as imagens permanecem ilustrações abstratas. Consulte `PENDENTE-IMAGENS-REALISTAS.md`.

> **Atualização da validação:** os quatro arquivos da pasta `prints/` foram substituídos por capturas reais do site executado no Chromium headless, nas larguras indicadas. Não são mais mockups programáticos.

## Última execução real (nesta sessão)
Rodei o motor completo em DOM real (jsdom) sobre o `index.html` desta
entrega e confirmei, com saída de teste automatizada:
- ✅ Zero erros de console/runtime.
- ✅ `index.html` é HTML real; `node --check` no JavaScript extraído sem erros de sintaxe.
- ✅ Zero IDs duplicados.
- ✅ Menu mobile: fechado totalmente invisível (`visibility:hidden` +
  `pointer-events:none`); abre, fecha com Esc/clique fora, trava scroll,
  devolve foco.
- ✅ Modal: abre, tamanho/quantidade/entrega-retirada/observação refletem
  corretamente na prévia da mensagem e no total; trava de foco (Tab/
  Shift+Tab não escapam do modal); Esc e clique externo fecham.
- ✅ Modo demonstração (`modoDemonstracao:true`): nenhum link expõe
  `wa.me` com o número; todos os botões abrem o modal de exemplo.
- ✅ Modo real (testado temporariamente com número fictício): botão
  "Enviar" monta a URL `wa.me` corretamente, sem envio automático.
- ✅ Fallback do logotipo: testado disparando um evento de erro de
  carregamento — cai para o emoji, sem ícone de imagem quebrada.
- ✅ SEO: metatags estáticas da seção `head` conferidas caractere a caractere
  com o texto exigido; `og:image` sempre absoluta.
- ✅ Todos os 13 arquivos de `img/` existem no disco, carregam, e nenhum
  caminho do CONFIG aponta para arquivo inexistente (zero 404).
- ✅ ZIP: extraído em pasta nova, `index.html` aberto de lá, mesmo
  resultado do original (caminhos relativos preservados).

Marque os itens abaixo manualmente ao revisar num navegador real —
os marcados **(✓ automatizado)** já foram cobertos pela rodada acima.

## Sobre os prints (`prints/`)
Os quatro arquivos são **capturas reais do site executado em Chromium headless**:

- `desktop-1440.png`: página completa com viewport de 1440 px;
- `mobile-390.png`: página completa com viewport de 390 px;
- `cardapio.png`: recorte real da seção do cardápio;
- `modal-pedido.png`: página real com o modal demonstrativo aberto.

As imagens dos alimentos continuam provisórias e abstratas; somente o método de captura foi atualizado.

## Desktop
- [ ] Layout completo sem cortes em 1024px e 1440px de largura.
- [ ] Banner principal, cardápio, sobre, atendimento, avaliações e rodapé
      aparecem corretamente.
- [ ] Sem rolagem horizontal. **(✓ automatizado — CSS sem overflow)**

## Celular
- [ ] Layout sem cortes em 320px, 375px, 390px e 430px.
- [ ] Sem rolagem horizontal em nenhuma dessas larguras.
- [ ] Inputs (observação do pedido) não causam zoom automático no iPhone
      (fonte 16px já aplicada no CSS). **(✓ automatizado — checado no CSS)**

## Menu mobile
- [ ] Fechado: **nenhuma parte fica visível** no topo da página.
      **(✓ automatizado — `visibility:hidden` + `pointer-events:none` confirmados)**
- [ ] Abre ao clicar no ícone; ícone vira "X". **(✓ automatizado)**
- [ ] Fecha ao clicar fora, ao apertar Esc e ao clicar num link.
      **(✓ automatizado)**
- [ ] Rolagem do fundo trava enquanto o menu está aberto. **(✓ automatizado)**
- [ ] `aria-expanded` atualiza corretamente. **(✓ automatizado)**
- [ ] Foco retorna ao botão do menu ao fechar. **(✓ automatizado)**

## Navegação
- [ ] Todos os links do menu (desktop, mobile, rodapé) rolam para a
      seção certa.
- [ ] Botão "Fazer pedido" do cabeçalho leva ao cardápio.

## Categorias (abas do cardápio)
- [ ] Clique troca a categoria ativa. **(✓ automatizado)**
- [ ] Navegação por teclado funciona (setas, Home, End). **(✓ automatizado)**
- [ ] `aria-selected` e `aria-controls` corretos. **(✓ automatizado)**
- [ ] Indicador visual da aba ativa não depende só de cor.

## Imagens
- [ ] Todas as 15 fotos do cardápio carregam. **(✓ automatizado)**
- [ ] Hero, Sobre, logo e imagem de compartilhamento carregam.
- [ ] Nenhuma imagem quebrada; nenhum texto "sua foto aqui" visível.
      **(✓ automatizado)**
- [ ] Fallback do logotipo: se `img/logo.png` falhar, mostra o emoji sem
      ícone de imagem quebrada. **(✓ automatizado — simulado com evento de erro)**

## Modal de pedido
- [ ] Abre ao clicar em "Pedir" em qualquer item, no hero, no CTA final
      e no botão flutuante.
- [ ] Título e descrição do produto aparecem corretos.
- [ ] Escape fecha o modal. **(✓ automatizado)**
- [ ] Clique fora (na área escurecida) fecha o modal.
- [ ] Foco retorna ao botão que abriu o modal. **(✓ automatizado)**
- [ ] Trava de foco: Tab no último elemento volta ao primeiro; Shift+Tab
      no primeiro vai ao último — o foco não escapa do modal.
      **(✓ automatizado)**

## Tamanhos
- [ ] Produtos com tamanho mostram os botões P/M/G (ou equivalentes).
- [ ] Seleção é única (só um tamanho ativo por vez). **(✓ automatizado)**
- [ ] Preço exibido atualiza ao trocar o tamanho. **(✓ automatizado)**

## Quantidade
- [ ] Botões +/− ajustam a quantidade (mínimo 1). **(✓ automatizado)**
- [ ] Quantidade > 1 aparece na mensagem. **(✓ automatizado)**

## Entrega
- [ ] Com `visibilidade.entrega=true`: chip, card no atendimento e opção
      no modal aparecem.
- [ ] Com `visibilidade.entrega=false`: nenhum dos três aparece, e nenhum
      texto do site menciona entrega. **(✓ automatizado)**

## Retirada
- [ ] Mesmo comportamento acima, para retirada. **(✓ automatizado)**

## Observações
- [ ] Campo de observação aceita texto livre e reflete na prévia da
      mensagem.

## Total do pedido
- [ ] Total = preço do tamanho selecionado × quantidade, sempre correto.
      **(✓ automatizado)**
- [ ] Total atualiza com `aria-live` (leitores de tela acompanham).
      **(✓ automatizado)**

## Mensagem do WhatsApp
- [ ] Contém produto, tamanho (quando existir), quantidade (se >1),
      entrega/retirada (se selecionado) e observação (se preenchida).
      **(✓ automatizado)**
- [ ] Nenhum campo aparece incompleto (ex.: "tamanho: " vazio).

## Modo demonstração
- [ ] Faixa de aviso aparece no topo.
- [ ] Rodapé identifica "site demonstrativo".
- [ ] Nenhum botão abre WhatsApp real; nenhum link expõe o número
      fictício. **(✓ automatizado)**
- [ ] Todos os botões de pedido abrem o modal demonstrativo.
- [ ] Avaliações mostram o selo "Avaliação demonstrativa".
- [ ] Nenhuma mensagem é enviada automaticamente em nenhum cenário.

## Modo real
- [ ] Com `modoDemonstracao:false` e um número (real ou de teste), o
      botão "Enviar pelo WhatsApp" abre o WhatsApp com a mensagem certa.
      **(✓ automatizado, com número fictício de teste)**
- [ ] Faixa de aviso e selos de demonstração desaparecem.
- [ ] Depois do teste, `modoDemonstracao` volta para `true` (ou é
      substituído pelo número definitivo do cliente) antes da entrega.

## Mapa
- [ ] Sem `mapaEmbedUrl`: mostra o placeholder com endereço.
- [ ] Com `mapaEmbedUrl`: mostra o iframe do Google Maps.
- [ ] Botão "Ver localização" abre `mapaLink`, ou o link gerado a partir
      de `latitude`/`longitude` quando `mapaLink` está vazio.
      **(✓ automatizado)**

## Instagram
- [ ] Em modo demonstração, o link do Instagram não abre página real.
- [ ] Em modo real, abre o Instagram do cliente em nova aba.
- [ ] Some do rodapé quando `visibilidade.instagram=false`.

## SEO
- [ ] Elemento `title` e meta description corretos (estático no HTML e após o
      JavaScript rodar). **(✓ automatizado)**
- [ ] Open Graph (title/description/type) corretos. **(✓ automatizado)**
- [ ] Twitter Card = `summary_large_image`. **(✓ automatizado)**
- [ ] Favicon aparece na aba do navegador.

## Compartilhamento
- [ ] `og:image` sempre vira uma URL **absoluta** (nunca caminho
      relativo quebrado). **(✓ automatizado)**
- [ ] Depois de publicado: colar a URL no verificador de compartilhamento
      do WhatsApp/Facebook e confirmar que a prévia mostra a imagem certa.

## Acessibilidade
- [ ] Todas as imagens têm `alt`.
- [ ] Foco visível em botões, links e abas.
- [ ] Abas e modal navegáveis por teclado.
- [ ] Contraste de texto adequado (paleta já pensada para isso).

## Console
- [ ] Nenhum erro no console do navegador em nenhuma tela.
      **(✓ automatizado)**

## Links
- [ ] Todos os links internos (âncoras `#`) funcionam.
- [ ] Links externos (Instagram, mapa) abrem em nova aba quando aplicável.

## Arquivos inexistentes
- [ ] Nenhuma referência a arquivo que não existe na pasta `img/`.
      **(✓ automatizado — todos os caminhos do CONFIG conferidos contra o disco)**

## Velocidade
- [ ] Imagens otimizadas (a maioria abaixo de 30 KB cada, formato WebP).
- [ ] Nenhuma imagem maior que ~250 KB.

## Rolagem horizontal
- [ ] Nenhuma tela produz barra de rolagem horizontal, em nenhuma
      largura testada.

---

## Validação técnica final
- [ ] HTML sem erros estruturais (tags fechadas corretamente).
- [ ] JavaScript sem erros de sintaxe (`node --check` executado sobre o
      script extraído). **(✓ automatizado)**
- [ ] Nenhum ID duplicado no documento. **(✓ automatizado)**
- [ ] Todos os seletores usados pelo JS encontram os elementos
      correspondentes (nenhum `null` inesperado). **(✓ automatizado)**
