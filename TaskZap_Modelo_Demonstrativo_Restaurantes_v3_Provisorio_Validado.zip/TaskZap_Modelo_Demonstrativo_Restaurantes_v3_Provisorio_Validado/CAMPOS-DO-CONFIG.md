# Campos do CONFIG — Referência completa

O `CONFIG` fica no `index.html`, dentro da tag `script`, logo após o
elemento `body`. Está organizado em 12 blocos. Esta página explica cada um e
marca com **🔴 obrigatório** os campos que precisam ser alterados sempre
que o modelo for adaptado para um cliente real.

---

## 1. Identidade
| Campo | O que é | Obrigatório? |
|---|---|---|
| `nome` | Nome do negócio | 🔴 sim |
| `slogan` | Frase curta abaixo do nome | 🔴 sim |
| `emoji` | Emoji usado como logo se `imagens.logo` estiver vazio ou falhar | recomendado |
| `cidade` | Cidade/UF, usada no eyebrow do hero | 🔴 sim |

## 2. Modo demonstração
| Campo | O que é | Obrigatório? |
|---|---|---|
| `modoDemonstracao` | `true` = contatos travados e modal de exemplo; `false` = WhatsApp real | 🔴 sim — mudar para `false` antes da entrega final ao cliente |

## 3. Contatos
| Campo | O que é | Obrigatório? |
|---|---|---|
| `whatsapp` | Número real do cliente (só dígitos: 55+DDD+número) | 🔴 sim |
| `msgPadrao` | Prefixo da mensagem de pedido; vazio = gerado automaticamente | opcional |
| `msgGeral` | Mensagem dos botões gerais (hero/CTA/flutuante); vazio = gerado | opcional |
| `instagram` | @usuário exibido no rodapé | recomendado |
| `instagramUrl` | Link real do Instagram | 🔴 sim, se `visibilidade.instagram=true` |

## 4. Endereço / Mapa
| Campo | O que é | Obrigatório? |
|---|---|---|
| `endereco` | Endereço completo | 🔴 sim |
| `enderecoCurto` | Versão curta (usada em cards e placeholder do mapa) | 🔴 sim |
| `areaAtendimento` | Frase sobre a área de entrega | 🔴 sim, se `visibilidade.entrega=true` |
| `mapaEmbedUrl` | `src` do iframe do Google Maps — mostra o mapa embutido | recomendado |
| `mapaLink` | Link "Como chegar"; tem prioridade sobre lat/long | opcional |
| `latitude` / `longitude` | Usados para montar o link do mapa quando `mapaLink` está vazio | opcional |

## 5. Operação
| Campo | O que é | Obrigatório? |
|---|---|---|
| `horarios[]` | Lista `{dia, hora}` | 🔴 sim |
| `tempoRetirada` | Tempo estimado de retirada | 🔴 sim, se `visibilidade.retirada=true` |
| `entregaInfo` | Texto usado no card de entrega da seção Atendimento | 🔴 sim, se `visibilidade.entrega=true` |
| `pagamentos` | Formas de pagamento aceitas | 🔴 sim |
| `mensagemInclui{}` | Liga/desliga produto/tamanho/quantidade/observação/entrega-retirada na mensagem do WhatsApp | opcional |

## 6. Cores
| Campo | O que é |
|---|---|
| `fundo`, `superficie`, `texto`, `textoSecundario` | Paleta neutra (fundo da página, cards, texto) |
| `marca`, `marcaEscura` | Cor principal da marca (header ativo, seção Atendimento, botões) |
| `acao`, `suave` | Cor de destaque (preços, CTAs) e sua versão clara |
| `etiqueta` | Cor das etiquetas "Mais pedido"/"Novo"/etc. |
| `linhas` | Cor de bordas e divisórias |

Não são obrigatórios trocar, mas devem refletir a identidade visual do
cliente quando o negócio tiver uma paleta própria.

## 7. Imagens
| Campo | O que é | Obrigatório? |
|---|---|---|
| `logo` / `logoAlt` | Logotipo (cabeçalho e rodapé) + texto alternativo | recomendado |
| `hero` / `heroAlt` | Foto do banner principal | 🔴 sim, para entrega comercial |
| `sobre` / `sobreAlt` | Foto da seção "Sobre" | 🔴 sim, para entrega comercial |
| `compartilhamento` | Imagem 1200×630 usada no link (WhatsApp/redes) | 🔴 sim |

## 8. Textos
Bloco com todo o conteúdo textual que muda conforme o **segmento** do
negócio (restaurante, marmitaria, hamburgueria, sorveteria, doceria,
pizzaria etc.): `heroEyebrow`, `heroLead`, `heroTagTitulo/Subtitulo`,
`chips[]`, títulos/subtítulos de cada seção, `sobre[]`, `ctaTitulo/ctaTexto`,
`rodapeTexto`, `menuRotulos{}`, `botoes{}`, `destaques[]`,
`mapaPlaceholderTexto`, `avisoDemoBarra`, `avisoDemoRodape`.
🔴 Revisar todo o bloco ao trocar de segmento — nada disso é fixo no motor.

## 9. Cardápio
`categorias[]` → cada categoria tem `id`, `nome`, `emoji` e `itens[]`. Cada
item: `nome`, `desc`, `etiqueta` (opcional), `foto`, `alt`, e **ou** `preco`
**ou** `tamanhos:[{rot,preco}]`. 🔴 Sempre obrigatório revisar para um cliente real.

## 10. Avaliações
| Campo | O que é |
|---|---|
| `avaliacoes[]` | Lista `{nota, texto, nome, info}` |
| `avaliacoesTitulo` | Título usado quando `modoDemonstracao=false` |
| `avaliacoesTituloDemo` | Título usado em modo demonstração |
| `avaliacoesSeloTexto` | Texto do selo "Avaliação demonstrativa" |
| `avaliacoesNota` | Nota de rodapé exibida em modo demonstração |
| `mostrarSeloAvaliacaoReal` | Se `true`, mantém o selo mesmo com `modoDemonstracao=false` |

🔴 Ao entregar para um cliente real, usar avaliações verídicas (com
autorização de quem avaliou) ou desativar a seção (`visibilidade.avaliacoes=false`).

## 11. Visibilidade
Liga/desliga seções sem deixar buracos no layout: `sobre`, `avaliacoes`,
`mapa`, `entrega`, `retirada`, `instagram`, `bebidas`, `sobremesas`,
`botaoFlutuante`, `selosProdutos`. Ajustar conforme o que o cliente
realmente oferece (ex.: só retirada → `entrega:false`).

## 12. SEO
| Campo | O que é | Obrigatório? |
|---|---|---|
| `title` / `description` | Título e descrição da aba/buscadores | 🔴 sim |
| `ogTitle` / `ogDescription` / `ogType` | Dados da prévia ao compartilhar o link | 🔴 sim |
| `ogImage` | Vazio = usa `imagens.compartilhamento` automaticamente | opcional |
| `favicon` | Ícone da aba do navegador | recomendado |
| `canonical` | URL final do site publicado | 🔴 preencher **depois** de publicar (fica vazio antes disso) |

> Os campos de `seo` também existem como texto estático na seção `head` do
> HTML (fora do CONFIG), para funcionar mesmo sem JavaScript. Ao editar
> o SEO, atualize **os dois lugares**.

---

## Resumo — o que sempre precisa mudar para um cliente real
`identidade` completo · `contato.whatsapp` (e Instagram) · `local`
completo · `operacao` completo · `categorias` (cardápio) · `imagens`
(hero, sobre, compartilhamento, logo) · `modoDemonstracao: false` ·
`seo` (title/description/ogTitle/ogDescription) · `seo.canonical`
(após publicar).
