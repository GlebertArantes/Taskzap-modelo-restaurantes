# Imagens pendentes — substituição por fotografia realista

Este projeto está usando **imagens provisórias** (composições abstratas
geradas por código: mesa/prato estilizado, iluminação quente, paleta da
marca — não fotografias). Elas existem só para que o site abra sem
nenhum link quebrado e o pacote possa ser testado de ponta a ponta.
**Nenhuma delas deve ser usada na apresentação comercial final.**

Quando as fotografias reais forem produzidas ou fornecidas, a
substituição é simples: trocar o arquivo em `img/` **mantendo o nome
exato** listado abaixo — o `CONFIG` dentro do `index.html` já aponta
para esses nomes e não precisa ser alterado.

---

### `img/logo.png`
- **Onde aparece:** badge do cabeçalho, badge do rodapé, favicon da aba do navegador.
- **Dimensão recomendada:** 512×512px.
- **Proporção:** 1:1, fundo **transparente** (PNG com canal alfa).
- **Orientação visual:** logotipo simples, legível mesmo pequeno (~38px
  no cabeçalho); símbolo relacionado a comida caseira; cores da marca
  (verde `#2C5540`, mostarda `#E2A33C`, laranja `#D8542E`).
- **Peso máximo recomendado:** 30 KB.

### `img/hero.webp`
- **Onde aparece:** banner principal (topo do site, primeira coisa que o visitante vê).
- **Dimensão recomendada:** 1600×2000px.
- **Proporção:** 4:5 (vertical no computador). No celular a mesma imagem
  é recortada em 5:4 (horizontal) automaticamente pelo CSS — ao
  fotografar, deixe o prato/assunto centralizado com espaço de respiro
  nas bordas para os dois recortes funcionarem.
- **Orientação visual:** refeição caseira bem apresentada sobre uma
  mesa; iluminação natural e acolhedora; sem pessoas identificáveis;
  cores que combinem com verde/creme/laranja/mostarda do site.
- **Peso máximo recomendado:** 150 KB.

### `img/sobre.webp`
- **Onde aparece:** seção "Sobre" (história/preparo).
- **Dimensão recomendada:** 1400×1400px.
- **Proporção:** 1:1 (quadrada).
- **Orientação visual:** cena de preparo em cozinha limpa e acolhedora;
  pode mostrar mãos preparando/finalizando um prato, sem identificar
  uma pessoa real; iluminação natural.
- **Peso máximo recomendado:** 120 KB.

### Fotos de produtos do cardápio
| Arquivo | Produto no cardápio |
|---|---|
| `img/marmita-tradicional.webp` | Marmita do Dia |
| `img/marmita-fitness.webp` | Marmita Fitness |
| `img/marmita-vegetariana.webp` | Marmita Vegetariana |
| `img/feijoada.webp` | Feijoada da Casa |
| `img/frango-quiabo.webp` | Frango com Quiabo |
| `img/parmegiana.webp` | Filé à Parmegiana |
| `img/porcoes.webp` | Categoria Porções (reaproveitada nos 3 itens) |
| `img/bebidas.webp` | Categoria Bebidas (reaproveitada nos 3 itens) |
| `img/sobremesas.webp` | Categoria Sobremesas (reaproveitada nos 3 itens) |

- **Onde aparecem:** card de cada item do cardápio.
- **Dimensão recomendada:** 1200×800px.
- **Proporção:** 16:11.
- **Orientação visual:** o prato/produto deve corresponder visualmente
  ao nome (ex.: `feijoada.webp` precisa parecer feijoada, não marmita
  genérica); mesmo tratamento de luz e cor entre todas, para parecer
  produzidas pelo mesmo fotógrafo/estabelecimento; fundo neutro ou mesa
  consistente com o hero.
- **Corte:** os cards usam `object-fit:cover` — o centro da imagem é
  sempre priorizado, então centralize o prato no enquadramento.
- **Peso máximo recomendado:** 80 KB cada.
- **Opcional (melhoria futura):** trocar as 3 categorias que hoje
  reaproveitam uma imagem genérica (Porções, Bebidas, Sobremesas) por
  fotos individuais por produto — nesse caso, adicionar o novo arquivo
  em `img/` e apontar o campo `foto` daquele item específico em
  `CONFIG.categorias` dentro do `index.html`.

### `img/compartilhamento.webp`
- **Onde aparece:** prévia do link ao compartilhar o site no WhatsApp/redes.
- **Dimensão obrigatória:** 1200×630px (padrão universal de Open Graph).
- **Proporção:** 1.91:1.
- **Orientação visual:** pode combinar foto de comida + logo + nome
  "Sabor da Casa" + frase curta; sem telefone/endereço reais.
- **Peso máximo recomendado:** 300 KB.

---

## Depois que as fotos chegarem
1. Substitua os 13 arquivos em `img/` pelos nomes exatos acima.
2. Rode a `CHECKLIST-DE-TESTES.md` novamente (seção de imagens).
3. Gere os 4 prints definitivos (`prints/desktop-1440.png`,
   `mobile-390.png`, `cardapio.png`, `modal-pedido.png`) com as fotos
   reais já aplicadas.
4. Só então publicar no Netlify.

Este arquivo deixa de fazer sentido assim que as fotos reais forem
aplicadas — pode ser removido do pacote na entrega definitiva.
